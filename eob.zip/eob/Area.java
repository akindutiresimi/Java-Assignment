/*import Scanner 
collect input of radius 
intilization of radius 
calculation area with the formua give
print result*/


import java.util.Scanner;
	
	public class Area{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);

	System.out.print("Enter radius");
	double radius = input.nextDouble();

	double area = 3.14 * radius * radius;
	System.out.println(area);

	}

}
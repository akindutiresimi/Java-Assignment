/*initilize the variable of the money
 declare balance 
 declare deposite 
 using double 
print*/


import java.util.Scanner;
	public class Balance{
	public static void main(String[] args){  

	Scanner input = new Scanner(System.in);
	System.out.print("balance");
	double balance = input.nextDouble(); 

	double deposits = balance + 1200 ;
	double withdraws = deposits - 750.25;

	double interest = balance * 1.5 / 100;
	double newBalance = interest + deposits;

	System.out.println("newBalance" + newBalance);


	}
}
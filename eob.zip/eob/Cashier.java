/*import Scanner 
call cashier to read iteam
read quatity
the use formual to calculate sub total 
calculate vat 
calculate grand total 
print grand total*/

import java.util.Scanner;

	public class Cashier{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);

	System.out.print("price");
	double price = input.nextDouble();

	System.out.print("quantity");
	double quantity = input.nextDouble();

	double subTotal = price * quantity;
	double vat = subTotal * 0.20;

	double grandTotal = subTotal + vat;
	System.out.println(grandTotal);
	


	}

}

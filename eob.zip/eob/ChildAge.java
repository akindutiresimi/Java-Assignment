/* intilization of variable
using if and else
determine wether the 
number is big,medium, and small*/

import java.util. Scanner;
	public class ChildAge{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	System.out.print("age");
	int age = input.nextInt(); 

	if (age >= 18 && age <= 64 ){
	System.out.println("adult");
	} 

	else if (age >= 13 && age <= 17 ){
	System.out.println("Teenager");
	}

	else if (age <= 13 && age >= 0){
	System.out.println("Child");
	}

	else if (age > 65){
	System.out.println("Senior");
	}

	}
}
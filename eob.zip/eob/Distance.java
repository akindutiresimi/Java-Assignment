/* import Scanner 
 convert distance of miles to kilimeter
print the value of both*/   


import java.util.Scanner;
	
	public class Distance{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);

	System.out.print("Enter miles");
	double miles = input.nextDouble();  
		
	double kilometer = miles * 1.60934; 

	System.out.println(miles);
	System.out.println(kilometer);

	}
}

	
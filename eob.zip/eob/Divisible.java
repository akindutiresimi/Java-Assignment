/* import Scanner
collect an integer 
print the integer 
if the integer is divisible by 2 or odd otherwise*/


import java.util.Scanner;

	public class Divisible{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);

	System.out.print("number");
	int number = input.nextInt();

	if (number % 2 == 0){
	System.out.println("Even");
	}
	else {
   	    System.out.println("Odd");
	}
        
	      
	  
	}

}

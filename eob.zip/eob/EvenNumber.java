import java.util. Scanner;
	public class EvenNumber{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in);
	
	//System.out.print("month");
	//int month = input.nextInt();  

	int counter = 0;
	
	for(counter =0; counter <= 50; counter+=2){
	System.out.println(counter);
	}
	}
}
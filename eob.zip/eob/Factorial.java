import java.util. Scanner;
	public class Factorial{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in); 
	System.out.print("number");
	int number = input.nextInt();
	

	int counter = -1;
	
	while (counter >= number ){
	counter--;
	number = counter * counter;

	}
	System.out.println(number);
	}
}
import java.util.Scanner;

	public class ClassGrade{
	public static void main(String[] args){

		int total = 0;
		int gradeCounter = 1;
		while(gradeCounter <= 10);

	System.out.print("Enter grade");
	int grade = input.nextInt();
	total = total + grade;
	gradeCounter = gradeCounter + 1;

	int average = total / 10;

	System.out.println("the totall:" + total);
	System.out.println("the average:" + average);
	}

}
/* intilize the grade
use ifor rsle to 
allocaate the grade to each 
grade score.*/


import java.util.Scanner;	
	public class GradeTwo{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	System.out.print("grade");
	int grade = input.nextInt();
	
	if (grade >= 90 && grade <= 100){
	System.out.println("A");
	}

	if (grade >= 80.0 && grade < 90){
	System.out.println("B");
	}

	if (grade >= 70.0 && grade < 80){
	System.out.println("C");
	}

	if (grade >= 60.0 && grade <= 0){
	System.out.println("D");
	}

	else { 
	    System.out.println("F");
	}
	}


}


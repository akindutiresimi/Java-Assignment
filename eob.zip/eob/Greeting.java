/* write a program 
that greet 
asssigning a string called greeting*/


public class Greeting{
public static void main(String[] args){

String greeting = "good morning";
System.out.println(greeting);

greeting = "good evening";
System.out.println(greeting);
 


}

}
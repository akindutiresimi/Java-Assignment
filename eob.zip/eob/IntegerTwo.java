import java.util. Scanner;
	public class IntegerTwo{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in);
	
	System.out.print("integer");
	int integer = input.nextInt();  

	if (integer % 3 == 0  && integer % 5 == 0){
	System.out.println(integer); 
	} 

	else if (integer % 3 == 0){
	System.out.print(integer);
	} 

	else if (integer % 5 == 0){
	System.out.print(integer);
	}  

	else if (integer % 3 != 0  && integer % 5 != 0){
	System.out.println(integer);  
	} 
	}
} 

	
import java.util.Scanner;
	public class LargestThree{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	System.out.print("Enter first number");
	int number1 = input.nextInt();

	System.out.print("Enter number2");
	int number2 = input.nextInt();

	System.out.print("Enter number3");
	int number3 = input.nextInt(); 


	if (number1 > number2 && number1 > number3 ){         
	System.out.printf("number1 is largest %n");                                                                        
	}                                                                                                                

	if (number2 > number1 && number2 > number3){     
	System.out.printf("number2 is largest %n"); 
	}  	

	if (number3 > number1 && number3 > number2){
	System.out.printf("number3 is smallest %n"); 
	}  
	}
}  
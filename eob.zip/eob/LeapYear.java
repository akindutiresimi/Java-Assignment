/*collect a number 
use 4 divisible by 100
collect Scanner*/


import java.util. Scanner;
	public class LeapYear{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in);
	
	System.out.print("year");
	int year = input.nextInt();
	
	if (year % 4 == 0){
	System.out.println("it is a leap year"); 
	}

	if (year % 4 != 0){
	System.out.println("it is not a leap year");
	}
	
	}
}
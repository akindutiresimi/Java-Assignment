import java.util. Scanner;
	public class Loop{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in);
	
	//System.out.print("month");
	//int month = input.nextInt();  

	int counter = 1;
	
	for(counter = 1; counter <= 10; counter++){
	System.out.println(counter);
	}
	}
}
import java.util. Scanner;
	public class LoopFor{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in); 
	
	int counter = 1;
	for(counter = 1; counter >= 100; counter++){
	System.out.println(counter);
	}
	}
}
import java.util. Scanner;
	public class LoopTwo{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in); 
	
	int counter = 1;
	for(counter = 10; counter >= 1; counter--){
	System.out.println(counter);
	}
	}
}
/*Scanner input 
collect the name and age 
intilization of name and age variable
print*/   

import java.util.Scanner;

	public class NameAge{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	
	System.out.print("Enter name");
	String name = input.nextLine();

	System.out.print("Enter birthYear");
	int currentYear = 2025 
	int age = currentYear - birthyear;
	System.out.printf(" hello, %s, you are %s years old", name, age);
}

}
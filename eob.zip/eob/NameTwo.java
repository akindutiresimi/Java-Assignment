/*Scanner input 
collect the name and age 
intilization of name and age variable
print*/   

import java.util.Scanner;

	public class NameTwo{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	
	System.out.print("Enter name");
	String name = input.nextLine();

	System.out.print("Enter yearBirth");
	int yearBirth = input.nextInt();
 

	System.out.print("Enter age");
	int age = input.nextInt();

	System.out.println(name);
	System.out.println(yearBirth);
	System.out.println(age);

	}
}
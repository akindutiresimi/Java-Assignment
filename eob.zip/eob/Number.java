/*import scanner 
using for to calculate 
multiplication of 2 
addition  of 3*/



public class Number{
public static void main(String[] args){

	/*Scanner input = new Scanner(System.in);
	System.out.print("Enter numberOne"); 
	int numberOne = input.nextInt();*/  

	int number = 5;

	number = number + 3;
	number = number * 2;

	System.out.println(number);

	}

}
/*import Scanner 
user input two different value
use the value to compute sum
differences, product, and quotient*/ 

import java.util.Scanner;

	public class NumberThree{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	
	System.out.print("enter numberOne");
	int numberOne = input.nextInt();

	System.out.print("enter numberTwo");
	int numberTwo = input.nextInt();

	int differences = 0;
	int multiplication = 0;
	int division = 0;

	differences = numberOne - numberTwo;
	System.out.println(differences);

	multiplication = numberOne * numberTwo;
	System.out.println(multiplication);

	division = numberOne + numberTwo;
	System.out.println(division);
} 


	}
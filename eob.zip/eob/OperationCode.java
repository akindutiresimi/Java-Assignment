import java.util.Scanner;
	public class OperationCode{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	System.out.print("Enter a numberOne");
	double numberOne = input.nextDouble();  

	System.out.print("Enter numberTwo"); 
	double numberTwo = input.nextDouble();  

	System.out.print("operationCode (+,-,*,/)"); 
	double operationCode = input.nextDouble();  

	if(operationCode ("+")){
	  System.out.println(numberOne + numberTwo);
	} 

	 else if (operationCode ("-")){
	  System.out.println(numberOne - numberTwo);
	}

	 else if (operationCode ("*")){
	  System.out.println(numberOne * numberTwo);
	}

	else if (operationCode ("/")){
	  System.out.println(numberOne / numberTwo);
	}
	
	}
}
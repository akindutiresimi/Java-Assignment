import java.util. Scanner;
	public class Product{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in);

	int counter = 1;
	int product = 0;
	
	for(counter =1; counter <= 12; counter++){
	//System.out.println(counter); 

	product = counter * counter; 
	System.out.println(product);
	}
	
	//System.out.println();
	}
}
/* import Scanner 
collect the student score
scale the score by 2 
print the original and
the scaled score*/


import java.util.Scanner;

	public class ScaledScore{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);

	System.out.print("Score");
	int Score = input.nextInt();
	System.out.println(Score);s
	int scaledScore = Score * 2;
	System.out.print(scaledScore);

	}
}

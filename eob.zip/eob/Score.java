import java.util. Scanner;
	public class Score{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in);
	
	System.out.print("score");
	int score = input.nextInt();  


	if (score >= 90 && score <= 100){
	System.out.println("A");
	} 
 
	 else if (score >= 80 && score < 90){
	System.out.println("B");
	} 
	
	else if (score >= 70 && score < 80){
	System.out.println("C");
	}  

	else {
	System.out.println("F");
	}

	}
}
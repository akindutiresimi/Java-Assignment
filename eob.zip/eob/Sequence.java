/* import Scanner
 collecting three number
print the result of the three 
using the formual*/


import java.util.Scanner;
	
	public class Sequence{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);

	System.out.print("Enter firstNumber");
	int firstNumber = input.nextInt();  

	System.out.print("Enter SecondNumber");
	int secondNumber = input.nextInt(); 
 	 
	int thirdNumber = 0;
	/*System.out.print("Enter thirdNumber");
	double thirdNumber = input.nextDouble();*/

	thirdNumber = firstNumber + secondNumber;
	firstNumber = thirdNumber - 2;
	secondNumber = firstNumber * 3;

	System.out.println(thirdNumber); 
	System.out.println(firstNumber); 
	System.out.println(secondNumber);


	}

}



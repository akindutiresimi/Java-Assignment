/* write a program
bring two variable with different integer 
make variable one equal to variable two
also variable two equal to variable ne */

public class SequenceTwo{
	public static void main(String[] args){

	//Scanner input = new Scanner(System.in);

	int firstNumber = 20; 
	System.out.println(firstNumber); 

	int secondNumber = 30; 
	int a = secondNumber; 
	System.out.println(secondNumber);

	secondNumber = firstNumber;
	System.out.println(secondNumber);

	firstNumber = a; 
	System.out.println(firstNumber);
	
	}
}
	


import java.util. Scanner;
	public class SumThree{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in); 
	
	int counter = 1;
	int Sum = 0;

	for(counter = 1; counter <= 100; counter++){
	 //System.out.println(counter);
	Sum = Sum + counter;

	} 
	System.out.println(Sum);
	}
}
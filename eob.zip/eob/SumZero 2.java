import java.util. Scanner;
	public class SumZero{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in); 
	System.out.print("number");
	int number = input.nextInt();
	

	int counter = 1;
	 int Sum = 0;
	while (counter <= number ){

	System.out.print("number");
	number = input.nextInt();
 
	if (counter != -1){  
	
	} 
	Sum = Sum + number;
	
	}
	System.out.println(Sum);
	}
}
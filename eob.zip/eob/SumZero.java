import java.util. Scanner;
	public class SumZero{
	public static void main(String[] args){ 

	Scanner input = new Scanner(System.in); 
	System.out.print("number");
	int number = input.nextInt();
	
	counter = 1;
	Sum = 0;
	while (counter <= number ){
 
	if (counter != 0){ 
	Break; 

	Sum = Sum + Counter;
	} 

	System.out.println(sum);

	}
	System.out.println();
	}
	}
}
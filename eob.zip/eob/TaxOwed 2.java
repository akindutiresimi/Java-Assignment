 import java.util.Scanner;
	public class TaxOwed{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	System.out.print("Enter first");
	double first = input.nextDouble();

	System.out.print("Enter Second");
	double Second = input.nextDouble(); 

	System.out.print("Enter Third");
	double Third = input.nextDouble(); 
	
	if (Second >= 300000 && Second <= 600000){ 
	System.out.println(Second);
	}
 
	else if  (Third >= 600000){
	System.out.println(Third);  
	}
	double TaxOne = first * 0 / 100; 

	double TaxTwo = Second * 7 /100; 

	double TaxThree = Third * 17 / 100; 

	double totalTax = TaxTwo + TaxThree;

	System.out.println(totalTax);
	}
}
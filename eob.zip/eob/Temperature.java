/*import scanner 
collect input in celcius 
intialization of celcius and fahrenheit
intialization of formuale
print*/ 


import java.util.Scanner;

	public class Temperature{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	
	System.out.print("Enter celcius");
	int celcius = input.nextInt();

	int fahrenheit = (celcius * 9 / 5) + 32;
	System.out.println("fahrenheit" + fahrenheit);

	}
}
/*initilization of three number 
assign the 10,20, and 30
print them on seperate line*/   


public class ThreeInteger{
public static void main(String[] args){

	int numberOne = 10;
	int numberTwo = 20;
	int numberThree = 30;

	System.out.println("numberOne:," + numberOne);
	System.out.println("numberOne:" + numberTwo); 
	System.out.println("numberOne:" + numberThree);
	


	}



}
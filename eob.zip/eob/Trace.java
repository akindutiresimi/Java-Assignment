/*import Scanner
collect the variable  
using string only
 intilization of the variable
trace the number as it is in the question*/

import java.util.Scanner;
	public class Trace{
	public static void main(String[] aargs){ 

	Scanner input = new Scanner(System.in);

	System.out.print("name");
	String name = input.nextLine();

	System.out.print("length");
	int length = input.nextInt();

	System.out.println(name +"has" +length+ "letters.");
	


	}
}
 

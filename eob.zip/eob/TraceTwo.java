/* intilization of variable
using if and else
determine wether the 
number is big,medium, and small*/

import java.util. Scanner;
	public class TraceTwo{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	System.out.print("x");
	int x = input.nextInt(); 

	if (x > 20){
	System.out.println("Big");
	} 

	else if (x > 10){
	System.out.println("Medium");
	}

	else {
	System.out.println("Small");
	}

	}
}
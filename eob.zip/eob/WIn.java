/* initilization of variable 
 using iif statement 
to get the win ,draw and 
print*/

public class Win{
	public static void main(String[] args){
  

	int a = 5;
	int b = 10;

	if (a > b){
	System.out.println("a wins");
	}

	else if (a == b){
	System.out.println("Draw");
	}
	else {
	System.out.print("b wins");
	}
	}
}

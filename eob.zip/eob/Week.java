/* initilization of variable 
 using iif statement 
to get the win ,draw and 
print*/

public class Win{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);
	System.out.print("a");
	int a = input.nextInt(); 

	System.out.print("b");
	int b = input.nextInt();  

	a = 5;
	b = 10;

	if (a > b){
	System.out.println("a wins");
	}

	else if (a == b){
	System.out.println("Draw");

	else {
	System.out.print("b wins");
	}
	}
}

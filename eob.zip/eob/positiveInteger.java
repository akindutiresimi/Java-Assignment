/* import Scanner 
 initilazation of number 
colect number 
use if statement 
if the number is gretater than zero 
print positive*/


import java.util.Scanner;

	public class positiveInteger{
	public static void main(String[] args){

	Scanner input = new Scanner(System.in);

	System.out.print("number");
	int number = input.nextInt();

	if (number > 0){
	System.out.println("positive");
	}	

	}

}